package it.unicam.cs.pa.jbudget102627;

public interface IdManagerInterface {

    //getters & setters

    //other methods
    int generateIdOf(String s);
}
