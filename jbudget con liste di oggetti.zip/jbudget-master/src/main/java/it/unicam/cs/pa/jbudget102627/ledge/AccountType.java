package it.unicam.cs.pa.jbudget102627.ledge;

public enum AccountType {
    ASSET,
    LIABILITIES;
}
