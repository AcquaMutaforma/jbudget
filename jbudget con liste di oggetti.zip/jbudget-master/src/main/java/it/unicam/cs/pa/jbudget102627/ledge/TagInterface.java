package it.unicam.cs.pa.jbudget102627.ledge;

public interface TagInterface {

    //getters
    int getId();
    String getName();

    //setters
    void setId(int o);
    void setName(String s);
}
