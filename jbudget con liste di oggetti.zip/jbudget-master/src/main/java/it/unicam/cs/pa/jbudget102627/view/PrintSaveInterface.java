package it.unicam.cs.pa.jbudget102627.view;

import it.unicam.cs.pa.jbudget102627.Controller;
import it.unicam.cs.pa.jbudget102627.saver.SaverInterface;

public interface PrintSaveInterface {

    void save(Controller controller, SaverInterface save);

}
